package dev.aaronhsu.capybara;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.biome.v1.BiomeModifications;
import net.fabricmc.fabric.api.biome.v1.BiomeSelectors;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricDefaultAttributeRegistry;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.Identifier;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.entity.SpawnPlacements;
import net.minecraft.world.entity.SpawnPlacementTypes;
import net.minecraft.world.entity.animal.Animal;
import net.minecraft.world.level.biome.Biomes;
import net.minecraft.world.level.levelgen.Heightmap;

public final class CapybaraMod implements ModInitializer {
    public static final String MOD_ID = "capybara";
    public static final Identifier CAPYBARA_ID = Identifier.fromNamespaceAndPath(MOD_ID, "capybara");
    public static final ResourceKey<EntityType<?>> CAPYBARA_KEY = ResourceKey.create(Registries.ENTITY_TYPE, CAPYBARA_ID);
    public static final EntityType<CapybaraEntity> CAPYBARA = Registry.register(
            BuiltInRegistries.ENTITY_TYPE,
            CAPYBARA_KEY,
            EntityType.Builder.of(CapybaraEntity::new, MobCategory.CREATURE)
                    .sized(0.9F, 0.75F)
                    .clientTrackingRange(10)
                    .build(CAPYBARA_KEY)
    );

    @Override
    public void onInitialize() {
        FabricDefaultAttributeRegistry.register(CAPYBARA, CapybaraEntity.createAttributes());
        SpawnPlacements.register(CAPYBARA, SpawnPlacementTypes.ON_GROUND,
                Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, Animal::checkAnimalSpawnRules);
        BiomeModifications.addSpawn(
                BiomeSelectors.includeByKey(Biomes.RIVER, Biomes.SWAMP, Biomes.MANGROVE_SWAMP),
                MobCategory.CREATURE, CAPYBARA, 32, 2, 4
        );
    }
}
