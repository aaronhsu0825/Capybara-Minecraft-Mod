package dev.aaronhsu.donutbalance.mixin;

import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.network.chat.Style;
import net.minecraft.util.FormattedCharSequence;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

import java.util.regex.Pattern;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.regex.Matcher;

@Mixin(GuiGraphicsExtractor.class)
abstract class GuiGraphicsExtractorMixin {
    // The live balance changes and DonutSMP may submit the green currency
    // symbol separately. Match the abbreviated amount itself (for example
    // 61.3M) so both the sidebar and TAB footer continue to work.
    private static final Pattern BALANCE = Pattern.compile(
            "(?i)\\b\\d{1,3}(?:[.,]\\d+)?\\s*[KMBTQ]\\b"
    );
    private static final StackWalker STACK_WALKER = StackWalker.getInstance();

    private enum HudLocation {
        NONE,
        SIDEBAR,
        TAB
    }

    @ModifyVariable(
            method = {
                    "text(Lnet/minecraft/client/gui/Font;Ljava/lang/String;III)V",
                    "text(Lnet/minecraft/client/gui/Font;Ljava/lang/String;IIIZ)V",
                    "centeredText(Lnet/minecraft/client/gui/Font;Ljava/lang/String;III)V"
            },
            at = @At("HEAD"), argsOnly = true, ordinal = 0
    )
    private String donutBalance$replaceString(String text) {
        return replace(text, hudLocation());
    }

    @ModifyVariable(
            method = {
                    "text(Lnet/minecraft/client/gui/Font;Lnet/minecraft/util/FormattedCharSequence;III)V",
                    "text(Lnet/minecraft/client/gui/Font;Lnet/minecraft/util/FormattedCharSequence;IIIZ)V",
                    "centeredText(Lnet/minecraft/client/gui/Font;Lnet/minecraft/util/FormattedCharSequence;III)V"
            },
            at = @At("HEAD"), argsOnly = true, ordinal = 0
    )
    private FormattedCharSequence donutBalance$replaceFormatted(FormattedCharSequence sequence) {
        List<Integer> codepoints = new ArrayList<>();
        List<Style> styles = new ArrayList<>();
        sequence.accept((index, style, codepoint) -> {
            codepoints.add(codepoint);
            styles.add(style);
            return true;
        });

        StringBuilder plain = new StringBuilder();
        for (int codepoint : codepoints) plain.appendCodePoint(codepoint);
        Matcher matcher = BALANCE.matcher(plain);
        if (!matcher.find()) return sequence;

        HudLocation location = hudLocation();
        if (location == HudLocation.NONE) return sequence;

        List<Integer> replacedCodepoints = new ArrayList<>();
        List<Style> replacedStyles = new ArrayList<>();
        appendRange(codepoints, styles, replacedCodepoints, replacedStyles, 0, matcher.start());

        Style amountStyle = styles.get(matcher.start());
        // TAB includes its ping suffix in this same sequence. The sidebar does
        // not, so only the sidebar gets the extra alignment spacer.
        String replacement = location == HudLocation.TAB ? "12.8B" : " 12.8B";
        replacement.codePoints().forEach(codepoint -> {
            replacedCodepoints.add(codepoint);
            replacedStyles.add(amountStyle);
        });
        appendRange(codepoints, styles, replacedCodepoints, replacedStyles, matcher.end(), codepoints.size());

        return sink -> {
            for (int index = 0; index < replacedCodepoints.size(); index++) {
                if (!sink.accept(index, replacedStyles.get(index), replacedCodepoints.get(index))) return false;
            }
            return true;
        };
    }

    private static void appendRange(
            List<Integer> sourceCodepoints,
            List<Style> sourceStyles,
            List<Integer> targetCodepoints,
            List<Style> targetStyles,
            int start,
            int end
    ) {
        for (int index = start; index < end; index++) {
            targetCodepoints.add(sourceCodepoints.get(index));
            targetStyles.add(sourceStyles.get(index));
        }
    }

    private static String replace(String text, HudLocation location) {
        if (text == null || text.isEmpty()) return text;
        if (location == HudLocation.NONE) return text;
        // Sidebar submits the amount as a separate plain string. Its x-position
        // was calculated for the old value, so retain a leading spacer here.
        String replacement = location == HudLocation.TAB ? "12.8B" : " 12.8B";
        return BALANCE.matcher(text).replaceAll(replacement);
    }

    private static HudLocation hudLocation() {
        return STACK_WALKER.walk(frames -> {
            boolean sidebar = false;
            Iterator<StackWalker.StackFrame> iterator = frames.iterator();
            while (iterator.hasNext()) {
                String className = iterator.next().getClassName();
                if (className.equals("net.minecraft.client.gui.components.PlayerTabOverlay")) {
                    return HudLocation.TAB;
                }
                if (className.equals("net.minecraft.client.gui.Gui")) {
                    sidebar = true;
                }
            }
            return sidebar ? HudLocation.SIDEBAR : HudLocation.NONE;
        });
    }
}
