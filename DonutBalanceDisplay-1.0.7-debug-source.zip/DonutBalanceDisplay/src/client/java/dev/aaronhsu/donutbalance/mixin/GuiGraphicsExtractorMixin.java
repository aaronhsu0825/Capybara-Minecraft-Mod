package dev.aaronhsu.donutbalance.mixin;

import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.util.FormattedCharSequence;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

@Mixin(GuiGraphicsExtractor.class)
abstract class GuiGraphicsExtractorMixin {
    private static final Pattern BALANCE = Pattern.compile(
            "(?i)\\b\\d{1,3}(?:[.,]\\d+)?\\s*[KMBTQ]\\b"
    );
    private static final StackWalker STACK_WALKER = StackWalker.getInstance();
    private static final Set<String> SEEN = ConcurrentHashMap.newKeySet();

    @ModifyVariable(
            method = {
                    "text(Lnet/minecraft/client/gui/Font;Ljava/lang/String;III)V",
                    "text(Lnet/minecraft/client/gui/Font;Ljava/lang/String;IIIZ)V",
                    "centeredText(Lnet/minecraft/client/gui/Font;Ljava/lang/String;III)V"
            },
            at = @At("HEAD"), argsOnly = true, ordinal = 0
    )
    private String donutBalance$diagnoseString(String text) {
        diagnose("STRING", text);
        return text;
    }

    @ModifyVariable(
            method = {
                    "text(Lnet/minecraft/client/gui/Font;Lnet/minecraft/util/FormattedCharSequence;III)V",
                    "text(Lnet/minecraft/client/gui/Font;Lnet/minecraft/util/FormattedCharSequence;IIIZ)V",
                    "centeredText(Lnet/minecraft/client/gui/Font;Lnet/minecraft/util/FormattedCharSequence;III)V"
            },
            at = @At("HEAD"), argsOnly = true, ordinal = 0
    )
    private FormattedCharSequence donutBalance$diagnoseFormatted(FormattedCharSequence sequence) {
        StringBuilder plain = new StringBuilder();
        sequence.accept((index, style, codepoint) -> {
            plain.appendCodePoint(codepoint);
            return true;
        });
        diagnose("FORMATTED", plain.toString());
        return sequence;
    }

    private static void diagnose(String type, String text) {
        if (text == null || !BALANCE.matcher(text).find()) return;
        String callers = STACK_WALKER.walk(frames -> frames
                .limit(18)
                .map(frame -> frame.getClassName() + "#" + frame.getMethodName())
                .collect(Collectors.joining(" <- ")));
        String message = "[DonutBalanceDiagnostic] type=" + type
                + " text=" + text.replace('\n', ' ')
                + " callers=" + callers;
        if (SEEN.add(message)) System.out.println(message);
    }
}
