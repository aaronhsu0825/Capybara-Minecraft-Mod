package dev.aaronhsu.capybara.client;

import dev.aaronhsu.capybara.CapybaraEntity;
import dev.aaronhsu.capybara.CapybaraMod;
import net.minecraft.client.model.animal.pig.PigModel;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.client.renderer.entity.state.LivingEntityRenderState;
import net.minecraft.resources.Identifier;

public final class CapybaraRenderer extends MobRenderer<CapybaraEntity, LivingEntityRenderState, PigModel> {
    private static final Identifier TEXTURE = Identifier.fromNamespaceAndPath(CapybaraMod.MOD_ID, "textures/entity/capybara.png");

    public CapybaraRenderer(EntityRendererProvider.Context context) {
        super(context, new PigModel(context.bakeLayer(ModelLayers.PIG)), 0.45F);
    }

    @Override public LivingEntityRenderState createRenderState() { return new LivingEntityRenderState(); }
    @Override public Identifier getTextureLocation(LivingEntityRenderState state) { return TEXTURE; }
}
