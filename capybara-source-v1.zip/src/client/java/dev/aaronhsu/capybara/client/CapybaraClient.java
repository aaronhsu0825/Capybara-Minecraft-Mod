package dev.aaronhsu.capybara.client;

import dev.aaronhsu.capybara.CapybaraMod;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry;

public final class CapybaraClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        EntityRendererRegistry.register(CapybaraMod.CAPYBARA, CapybaraRenderer::new);
    }
}
