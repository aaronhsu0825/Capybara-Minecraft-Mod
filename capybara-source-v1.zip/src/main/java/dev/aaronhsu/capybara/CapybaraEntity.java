package dev.aaronhsu.capybara;

import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.animal.wolf.Wolf;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;

public final class CapybaraEntity extends Wolf {
    public CapybaraEntity(EntityType<? extends Wolf> type, Level level) {
        super(type, level);
        setCanPickUpLoot(false);
    }

    @Override
    public boolean isFood(ItemStack stack) {
        return stack.is(Items.MELON_SLICE);
    }

    @Override
    public InteractionResult mobInteract(Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (stack.is(Items.MELON_SLICE)) {
            if (!player.getAbilities().instabuild) stack.shrink(1);
            if (!isTame()) {
                if (!level().isClientSide()) {
                    if (getRandom().nextInt(3) == 0) {
                        tame(player);
                        getNavigation().stop();
                        setTarget(null);
                        setOrderedToSit(true);
                        level().broadcastEntityEvent(this, (byte) 7);
                    } else {
                        level().broadcastEntityEvent(this, (byte) 6);
                    }
                }
                return InteractionResult.SUCCESS;
            }
            if (getHealth() < getMaxHealth()) heal(4.0F);
            if (!level().isClientSide()) level().broadcastEntityEvent(this, (byte) 7);
            return InteractionResult.SUCCESS;
        }
        return super.mobInteract(player, hand);
    }

    @Override protected SoundEvent getAmbientSound() { return SoundEvents.PIG_AMBIENT; }
    @Override protected SoundEvent getHurtSound(DamageSource source) { return SoundEvents.PIG_HURT; }
    @Override protected SoundEvent getDeathSound() { return SoundEvents.PIG_DEATH; }
}
