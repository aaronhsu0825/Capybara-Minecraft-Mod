package dev.aaronhsu.autototem;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.client.Minecraft;
import net.minecraft.world.inventory.ContainerInput;
import net.minecraft.world.item.Items;

public final class AutoTotemClient implements ClientModInitializer {
    private static int cooldown;

    @Override
    public void onInitializeClient() {
        ClientTickEvents.END_CLIENT_TICK.register(AutoTotemClient::onEndTick);
    }

    private static void onEndTick(Minecraft minecraft) {
        if (cooldown > 0) {
            cooldown--;
            return;
        }
        if (minecraft.player == null || minecraft.gameMode == null) return;
        if (minecraft.getScreen() != null) return;
        if (!minecraft.player.getOffhandItem().isEmpty()) return;

        int inventoryIndex = -1;
        for (int index = 0; index < 36; index++) {
            if (minecraft.player.getInventory().getItem(index).is(Items.TOTEM_OF_UNDYING)) {
                inventoryIndex = index;
                break;
            }
        }
        if (inventoryIndex < 0) return;

        int menuSlot = inventoryIndex < 9 ? inventoryIndex + 36 : inventoryIndex;
        minecraft.gameMode.handleInventoryMouseClick(
                minecraft.player.inventoryMenu.containerId,
                menuSlot,
                40,
                ContainerInput.SWAP,
                minecraft.player
        );
        cooldown = 4;
    }
}
