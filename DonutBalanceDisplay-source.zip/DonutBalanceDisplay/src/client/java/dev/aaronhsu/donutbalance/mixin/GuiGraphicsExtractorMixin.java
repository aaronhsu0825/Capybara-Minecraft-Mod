package dev.aaronhsu.donutbalance.mixin;

import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.network.chat.Component;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

import java.util.regex.Pattern;

@Mixin(GuiGraphicsExtractor.class)
abstract class GuiGraphicsExtractorMixin {
    private static final Pattern BALANCE = Pattern.compile("(?i)(\\$\\s*)61\\.2M\\b");

    @ModifyVariable(
            method = {
                    "text(Lnet/minecraft/client/gui/Font;Ljava/lang/String;III)V",
                    "text(Lnet/minecraft/client/gui/Font;Ljava/lang/String;IIIZ)V",
                    "centeredText(Lnet/minecraft/client/gui/Font;Ljava/lang/String;III)V"
            },
            at = @At("HEAD"), argsOnly = true, ordinal = 0
    )
    private String donutBalance$replaceString(String text) {
        return replace(text);
    }

    @ModifyVariable(
            method = {
                    "text(Lnet/minecraft/client/gui/Font;Lnet/minecraft/network/chat/Component;III)V",
                    "text(Lnet/minecraft/client/gui/Font;Lnet/minecraft/network/chat/Component;IIIZ)V",
                    "centeredText(Lnet/minecraft/client/gui/Font;Lnet/minecraft/network/chat/Component;III)V"
            },
            at = @At("HEAD"), argsOnly = true, ordinal = 0
    )
    private Component donutBalance$replaceComponent(Component component) {
        String original = component.getString();
        String replaced = replace(original);
        if (original.equals(replaced)) return component;
        return Component.literal(replaced).withStyle(component.getStyle());
    }

    private static String replace(String text) {
        if (text == null || text.isEmpty()) return text;
        return BALANCE.matcher(text).replaceAll(match -> match.group(1) + "12.8B");
    }
}
