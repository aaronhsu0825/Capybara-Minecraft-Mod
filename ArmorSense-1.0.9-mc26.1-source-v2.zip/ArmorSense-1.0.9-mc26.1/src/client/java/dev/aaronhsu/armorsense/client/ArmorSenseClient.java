package dev.aaronhsu.armorsense.client;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.renderer.RenderPipelines;
import net.minecraft.resources.Identifier;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.item.ItemStack;

public final class ArmorSenseClient implements ClientModInitializer {
	private static final String MOD_ID = "armorsense";
	private static final Identifier HOTBAR_SPRITE = Identifier.withDefaultNamespace("hud/hotbar");

	private static final int HOTBAR_TEXTURE_WIDTH = 182;
	private static final int HOTBAR_HEIGHT = 22;
	private static final int SLOT_STEP = 20;
	private static final int ARMOR_HOTBAR_BODY_WIDTH = 81;
	private static final int ARMOR_HOTBAR_WIDTH = 82;
	private static final int SINGLE_HOTBAR_BODY_WIDTH = 21;
	private static final int SINGLE_HOTBAR_WIDTH = 22;
	private static final int HOTBAR_HALF_WIDTH = 91;
	private static final int HOTBAR_GAP = 6;
	private static final int ITEM_OFFSET_X = 3;
	private static final int ITEM_OFFSET_Y = 3;
	private static final int DURABILITY_BAR_WIDTH = 13;

	private static final int GREEN = 0xFF32E632;
	private static final int YELLOW = 0xFFFFD42A;
	private static final int RED = 0xFFFF3B30;

	private static final EquipmentSlot[] DISPLAY_ORDER = {
		EquipmentSlot.HEAD,
		EquipmentSlot.CHEST,
		EquipmentSlot.LEGS,
		EquipmentSlot.FEET
	};

	@Override
	public void onInitializeClient() {
		HudElementRegistry.attachElementAfter(
			VanillaHudElements.HOTBAR,
			Identifier.fromNamespaceAndPath(MOD_ID, "armor_hud"),
			ArmorSenseClient::renderHud
		);
	}

	private static void renderHud(GuiGraphicsExtractor graphics, DeltaTracker deltaTracker) {
		Minecraft minecraft = Minecraft.getInstance();
		if (minecraft.player == null) {
			return;
		}

		int hotbarLeft = graphics.guiWidth() / 2 - HOTBAR_HALF_WIDTH;
		int hotbarRight = graphics.guiWidth() / 2 + HOTBAR_HALF_WIDTH;
		int armorStartX = hotbarLeft - HOTBAR_GAP - ARMOR_HOTBAR_WIDTH;
		// Leave the first right-side slot for Minecraft's attack indicator.
		// The offhand slot sits directly beside it instead of overlapping it.
		int offhandStartX = hotbarRight + HOTBAR_GAP + SINGLE_HOTBAR_WIDTH;
		int startY = graphics.guiHeight() - HOTBAR_HEIGHT;

		drawHotbarSection(
			graphics,
			armorStartX,
			startY,
			0,
			ARMOR_HOTBAR_BODY_WIDTH,
			ARMOR_HOTBAR_WIDTH
		);
		drawHotbarSection(
			graphics,
			offhandStartX,
			startY,
			0,
			SINGLE_HOTBAR_BODY_WIDTH,
			SINGLE_HOTBAR_WIDTH
		);

		for (int index = 0; index < DISPLAY_ORDER.length; index++) {
			EquipmentSlot slot = DISPLAY_ORDER[index];
			ItemStack stack = minecraft.player.getItemBySlot(slot);
			int itemX = armorStartX + ITEM_OFFSET_X + index * SLOT_STEP;
			int itemY = startY + ITEM_OFFSET_Y;
			drawSlotContents(graphics, minecraft, stack, itemX, itemY, startY);
		}

		ItemStack offhandStack = minecraft.player.getOffhandItem();
		int offhandItemX = offhandStartX + ITEM_OFFSET_X;
		int offhandItemY = startY + ITEM_OFFSET_Y;
		drawSlotContents(
			graphics,
			minecraft,
			offhandStack,
			offhandItemX,
			offhandItemY,
			startY
		);
	}

	private static void drawSlotContents(
		GuiGraphicsExtractor graphics,
		Minecraft minecraft,
		ItemStack stack,
		int itemX,
		int itemY,
		int slotY
	) {
		if (stack.isEmpty()) {
			return;
		}

		if (!stack.isDamageableItem() || stack.getMaxDamage() <= 0) {
			graphics.item(stack, itemX, itemY);
			return;
		}

		int remaining = Math.max(0, stack.getMaxDamage() - stack.getDamageValue());
		double remainingPercent = remaining / (double) stack.getMaxDamage();
		int durabilityColor = durabilityColor(remainingPercent);

		graphics.item(stack, itemX, itemY);
		drawCenteredText(
			graphics,
			minecraft.font,
			Integer.toString(remaining),
			itemX + 8,
			slotY - 10,
			durabilityColor
		);

		if (stack.getDamageValue() > 0) {
			drawDurabilityBar(graphics, itemX, itemY, remainingPercent, durabilityColor);
		}
	}

	private static void drawHotbarSection(
		GuiGraphicsExtractor graphics,
		int x,
		int y,
		int sourceU,
		int bodyWidth,
		int totalWidth
	) {
		graphics.blitSprite(
			RenderPipelines.GUI_TEXTURED,
			HOTBAR_SPRITE,
			HOTBAR_TEXTURE_WIDTH,
			HOTBAR_HEIGHT,
			sourceU,
			0,
			x,
			y,
			bodyWidth,
			HOTBAR_HEIGHT
		);
		graphics.blitSprite(
			RenderPipelines.GUI_TEXTURED,
			HOTBAR_SPRITE,
			HOTBAR_TEXTURE_WIDTH,
			HOTBAR_HEIGHT,
			HOTBAR_TEXTURE_WIDTH - 1,
			0,
			x + totalWidth - 1,
			y,
			1,
			HOTBAR_HEIGHT
		);
	}

	private static void drawDurabilityBar(
		GuiGraphicsExtractor graphics,
		int itemX,
		int itemY,
		double remainingPercent,
		int color
	) {
		int barX = itemX + 2;
		int barY = itemY + 13;
		int filledWidth = (int) Math.round(DURABILITY_BAR_WIDTH * remainingPercent);
		filledWidth = Math.max(0, Math.min(DURABILITY_BAR_WIDTH, filledWidth));

		graphics.fill(
			barX,
			barY,
			barX + DURABILITY_BAR_WIDTH,
			barY + 2,
			0xFF000000
		);
		graphics.fill(barX, barY, barX + filledWidth, barY + 1, color);
	}

	private static void drawCenteredText(
		GuiGraphicsExtractor graphics,
		Font font,
		String text,
		int centerX,
		int y,
		int color
	) {
		int x = centerX - font.width(text) / 2;
		graphics.text(font, text, x + 1, y + 1, 0xFF000000, false);
		graphics.text(font, text, x, y, color, false);
	}

	private static int durabilityColor(double percent) {
		if (percent > 0.50) {
			return GREEN;
		}
		if (percent > 0.20) {
			return YELLOW;
		}
		return RED;
	}
}
