# ArmorSense

ArmorSense is a client-side Fabric mod for Minecraft Java Edition 26.2. It adds a
compact PvP armor display immediately to the left of the hotbar.

## Features

- Helmet, chestplate, leggings, and boots shown beside the hotbar
- Exact remaining durability displayed above every equipped item
- Green, yellow, and red condition colors
- Empty armor slots stay clean with no warning or red bar
- Four slots copied from Minecraft's real hotbar sprite
- Automatically matches the active resource pack's hotbar texture
- Replaces the vanilla offhand frame with a pixel-for-pixel copy of the fourth armor slot
- Renders offhand contents through the exact same code path as armor contents
- Uses the same six-pixel gap on both sides of the main hotbar
- Full-durability armor has no bar
- Damaged armor uses a thin, vanilla-style durability bar
- No warning messages or popups
- Fully client-side; it does not need to be installed on the server

Durability is green above 50%, yellow from 21–50%, and red at 20% or below.

## Installation

Install Fabric Loader, Fabric API, and place the ArmorSense JAR in the Minecraft
`mods` folder.

## Building

ArmorSense requires Java 25. Run:

```shell
./gradlew build
```

## License

ArmorSense is available under the CC0-1.0 license.
