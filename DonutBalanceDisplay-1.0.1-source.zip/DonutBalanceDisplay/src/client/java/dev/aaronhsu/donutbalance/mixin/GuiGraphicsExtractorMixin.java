package dev.aaronhsu.donutbalance.mixin;

import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.Style;
import net.minecraft.util.FormattedCharSequence;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

import java.util.regex.Pattern;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;

@Mixin(GuiGraphicsExtractor.class)
abstract class GuiGraphicsExtractorMixin {
    private static final Pattern BALANCE = Pattern.compile("(?i)(\\$\\s*)61\\.2M\\b");

    @ModifyVariable(
            method = {
                    "text(Lnet/minecraft/client/gui/Font;Ljava/lang/String;III)V",
                    "text(Lnet/minecraft/client/gui/Font;Ljava/lang/String;IIIZ)V",
                    "centeredText(Lnet/minecraft/client/gui/Font;Ljava/lang/String;III)V"
            },
            at = @At("HEAD"), argsOnly = true, ordinal = 0
    )
    private String donutBalance$replaceString(String text) {
        return replace(text);
    }

    @ModifyVariable(
            method = {
                    "text(Lnet/minecraft/client/gui/Font;Lnet/minecraft/network/chat/Component;III)V",
                    "text(Lnet/minecraft/client/gui/Font;Lnet/minecraft/network/chat/Component;IIIZ)V",
                    "centeredText(Lnet/minecraft/client/gui/Font;Lnet/minecraft/network/chat/Component;III)V"
            },
            at = @At("HEAD"), argsOnly = true, ordinal = 0
    )
    private Component donutBalance$replaceComponent(Component component) {
        String original = component.getString();
        String replaced = replace(original);
        if (original.equals(replaced)) return component;
        return Component.literal(replaced).withStyle(component.getStyle());
    }

    @ModifyVariable(
            method = {
                    "text(Lnet/minecraft/client/gui/Font;Lnet/minecraft/util/FormattedCharSequence;III)V",
                    "text(Lnet/minecraft/client/gui/Font;Lnet/minecraft/util/FormattedCharSequence;IIIZ)V",
                    "centeredText(Lnet/minecraft/client/gui/Font;Lnet/minecraft/util/FormattedCharSequence;III)V"
            },
            at = @At("HEAD"), argsOnly = true, ordinal = 0
    )
    private FormattedCharSequence donutBalance$replaceFormatted(FormattedCharSequence sequence) {
        List<Integer> codepoints = new ArrayList<>();
        List<Style> styles = new ArrayList<>();
        sequence.accept((index, style, codepoint) -> {
            codepoints.add(codepoint);
            styles.add(style);
            return true;
        });

        StringBuilder plain = new StringBuilder();
        for (int codepoint : codepoints) plain.appendCodePoint(codepoint);
        Matcher matcher = BALANCE.matcher(plain);
        if (!matcher.find()) return sequence;

        List<Integer> replacedCodepoints = new ArrayList<>();
        List<Style> replacedStyles = new ArrayList<>();
        appendRange(codepoints, styles, replacedCodepoints, replacedStyles, 0, matcher.start());

        int amountStart = matcher.start() + matcher.group(1).length();
        appendRange(codepoints, styles, replacedCodepoints, replacedStyles, matcher.start(), amountStart);
        Style amountStyle = styles.get(Math.min(amountStart, styles.size() - 1));
        "12.8B".codePoints().forEach(codepoint -> {
            replacedCodepoints.add(codepoint);
            replacedStyles.add(amountStyle);
        });
        appendRange(codepoints, styles, replacedCodepoints, replacedStyles, matcher.end(), codepoints.size());

        return sink -> {
            for (int index = 0; index < replacedCodepoints.size(); index++) {
                if (!sink.accept(index, replacedStyles.get(index), replacedCodepoints.get(index))) return false;
            }
            return true;
        };
    }

    private static void appendRange(
            List<Integer> sourceCodepoints,
            List<Style> sourceStyles,
            List<Integer> targetCodepoints,
            List<Style> targetStyles,
            int start,
            int end
    ) {
        for (int index = start; index < end; index++) {
            targetCodepoints.add(sourceCodepoints.get(index));
            targetStyles.add(sourceStyles.get(index));
        }
    }

    private static String replace(String text) {
        if (text == null || text.isEmpty()) return text;
        return BALANCE.matcher(text).replaceAll(match -> match.group(1) + "12.8B");
    }
}
